<?php
 
/**
 * Plugin Name:       Admin Bar Gone
 * Plugin URI:        https://github.com/iSohaibKhan/adminBarGone
 * Description:       This Plugin (Admin Bar Gone) lets you disable the Black Bar/Admin Bar up top from the Front-End of your WordPress Website, whenever admin logs into the admin dashboard afer that if you visit your website you'll see the Black Bar/Admin Bar up top which is not that useable & the disadvantage of having it enable is you could have issues during the development specially the hearder of your website so I've create this Plugin which comes handy for me, fell free to use it for yourself.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Sohaib S. Khan.
 * Author URI:        https://isohaibkhan.github.io
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       admin-bar-gone
 */

//MAIN FUNCION (FILTER HOOK TO DISABLE THE ADMIN BAR OF THE WORDPRESS ON FRONT-END:
 add_filter( 'show_admin_bar' , '__return_false' );
